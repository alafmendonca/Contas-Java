package conta;

public class ContaCorrente extends Conta{
	double limite;
	int gerente;
	double taxaMensal;


}
